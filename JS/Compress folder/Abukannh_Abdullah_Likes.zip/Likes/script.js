
var element = document.querySelectorAll(".like-Num");

var count;
function addLike(index){
    // var element = document.querySelector(".like-Num");
    // var count = Number(element.innerHTML);
    // count++;
    // element.innerHTML = count;

    
    console.log(element[index]);
    count = Number(element[index].innerHTML)+1;
    console.log(count);
    element[index].innerHTML = count;
    console.log(element);

}

function addAvatar(){

    var element = document.getElementById("avatar-image");
    var newAvatar = document.getElementById("avatar");
    // console.log(element.src);
    var selectroType = newAvatar.files[0].type;
    console.log(selectroType);
    // image/jpg image/png image/jpeg
    if (selectroType == "image/jpeg" || selectroType == "image/jpg" ){
        element.src = URL.createObjectURL(newAvatar.files[0]);
    }else{
        alert("the input is not Image")
    }
}