function playVideo(element){
    // console.log(element);
    element.play();
}
function pauseVideo(element){
    element.pause();
}
// function watchVideo(element){
//     console.log(element);
// }